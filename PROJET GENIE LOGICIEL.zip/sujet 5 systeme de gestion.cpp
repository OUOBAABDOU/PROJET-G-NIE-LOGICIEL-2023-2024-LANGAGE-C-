#include <iostream>
#include <vector>
#include <fstream>
#include <ctime>

struct Produit {
    int id;
    std::string nom;
    std::string description;
    double prix;
    int quantite;
};

struct Vente {
    int id;
    std::string nomProduit;
    int quantiteVendue;
    std::string date;
};

std::vector<Produit> produits;
std::vector<Vente> ventes;
int idProduit = 1;
int idVente = 1;

// Fonction pour ajouter un produit
void ajouterProduit() {
    Produit p;
    p.id = idProduit++;
    std::cout << "Nom du produit : ";
    std::cin.ignore();
    std::getline(std::cin, p.nom);
    std::cout << "Description : ";
    std::getline(std::cin, p.description);
    std::cout << "Prix : ";
    std::cin >> p.prix;
    std::cout << "Quantite : ";
    std::cin >> p.quantite;
    produits.push_back(p);
    std::cout << "Produit ajoute avec succès !" << std::endl;
}

// Fonction pour modifier un produit
void modifierProduit() {
    int id;
    std::cout << "Entrez l'ID du produit a modifier : ";
    std::cin >> id;
    for (auto &p : produits) {
        if (p.id == id) {
            std::cout << "Modifier le nom (actuel : " << p.nom << ") : ";
            std::cin.ignore();
            std::getline(std::cin, p.nom);
            std::cout << "Modifier la description (actuelle : " << p.description << ") : ";
            std::getline(std::cin, p.description);
            std::cout << "Modifier le prix (actuel : " << p.prix << ") : ";
            std::cin >> p.prix;
            std::cout << "Modifier la quantite (actuelle : " << p.quantite << ") : ";
            std::cin >> p.quantite;
            std::cout << "Produit modifie avec succès !" << std::endl;
            return;
        }
    }
    std::cout << "Produit non trouve !" << std::endl;
}

// Fonction pour supprimer un produit
void supprimerProduit() {
    int id;
    std::cout << "Entrez l'ID du produit a supprimer : ";
    std::cin >> id;
    for (auto it = produits.begin(); it != produits.end(); ++it) {
        if (it->id == id) {
            produits.erase(it);
            std::cout << "Produit supprime avec succès !" << std::endl;
            return;
        }
    }
    std::cout << "Produit non trouve !" << std::endl;
}

// Fonction pour rechercher des produits par nom
void rechercherProduit() {
    std::string nom;
    std::cout << "Entrez le nom du produit a rechercher : ";
    std::cin.ignore();
    std::getline(std::cin, nom);
    bool trouve = false;
    for (const auto &p : produits) {
        if (p.nom.find(nom) != std::string::npos) {
            std::cout << "ID: " << p.id << ", Nom: " << p.nom << ", Description: " << p.description
                      << ", Prix: " << p.prix << ", Quantite: " << p.quantite << std::endl;
            trouve = true;
        }
    }
    if (!trouve) {
        std::cout << "Aucun produit trouve !" << std::endl;
    }
}

// Fonction pour enregistrer une vente
void enregistrerVente() {
    int id, quantite;
    std::cout << "Entrez l'ID du produit vendu : ";
    std::cin >> id;
    std::cout << "Entrez la quantite vendue : ";
    std::cin >> quantite;

    for (auto &p : produits) {
        if (p.id == id) {
            if (quantite > p.quantite) {
                std::cout << "Quantite insuffisante !" << std::endl;
                return;
            }
            p.quantite -= quantite;
            Vente v;
            v.id = idVente++;
            v.nomProduit = p.nom;
            v.quantiteVendue = quantite;

            // Recuperation de la date actuelle
            std::time_t t = std::time(nullptr);
            char buffer[100];
            std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", std::localtime(&t));
            v.date = buffer;

            ventes.push_back(v);
            std::cout << "Vente enregistree avec succès !" << std::endl;
            return;
        }
    }
    std::cout << "Produit non trouve !" << std::endl;
}

// Fonction pour lister les ventes
void listerVentes() {
    if (ventes.empty()) {
        std::cout << "Aucune vente enregistree !" << std::endl;
        return;
    }
    for (const auto &v : ventes) {
        std::cout << "ID Vente: " << v.id << ", Nom Produit: " << v.nomProduit
                  << ", Quantite Vendue: " << v.quantiteVendue << ", Date: " << v.date << std::endl;
    }
}

// Fonction pour sauvegarder les produits dans un fichier
void sauvegarderProduits() {
    std::ofstream fichier("produits.txt");
    for (const auto &p : produits) {
        fichier << p.id << "," << p.nom << "," << p.description << ","
                << p.prix << "," << p.quantite << std::endl;
    }
    fichier.close();
    std::cout << "Produits sauvegardes avec succès !" << std::endl;
}

// Fonction pour charger les produits depuis un fichier
void chargerProduits() {
    std::ifstream fichier("produits.txt");
    if (!fichier) {
        std::cout << "Aucun fichier de produits trouve." << std::endl;
        return;
    }
    produits.clear();
    Produit p;
    char separateur;
    while (fichier >> p.id >> separateur && separateur == ',' &&
           std::getline(fichier, p.nom, ',') && std::getline(fichier, p.description, ',') &&
           fichier >> p.prix >> separateur && separateur == ',' && fichier >> p.quantite) {
        produits.push_back(p);
    }
    fichier.close();
    std::cout << "Produits charges avec succes !" << std::endl;
}

int main() {
    int choix;
    chargerProduits();
    do {
        std::cout << "\nMenu :\n";
        std::cout << "1. Ajouter un produit\n";
        std::cout << "2. Modifier un produit\n";
        std::cout << "3. Supprimer un produit\n";
        std::cout << "4. Rechercher des produits\n";
        std::cout << "5. Enregistrer une vente\n";
        std::cout << "6. Lister les ventes\n";
        std::cout << "7. Sauvegarder les produits\n";
        std::cout << "8. Quitter\n";
        std::cout << "Choisissez une option : ";
        std::cin >> choix;

        switch (choix) {
            case 1: ajouterProduit(); break;
            case 2: modifierProduit(); break;
            case 3: supprimerProduit(); break;
            case 4: rechercherProduit(); break;
            case 5: enregistrerVente(); break;
            case 6: listerVentes(); break;
            case 7: sauvegarderProduits(); break;
            case 8: std::cout << "Au revoir !" << std::endl; break;
            default: std::cout << "Option invalide !" << std::endl; break;
        }
    } while (choix != 8);

    return 0;
}